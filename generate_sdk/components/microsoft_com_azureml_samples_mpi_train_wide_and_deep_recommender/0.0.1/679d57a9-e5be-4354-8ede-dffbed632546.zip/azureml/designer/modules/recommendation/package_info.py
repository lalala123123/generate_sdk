VERSION = '0.0.1'
PACKAGE_NAME = 'azureml-designer-recommender-modules'
