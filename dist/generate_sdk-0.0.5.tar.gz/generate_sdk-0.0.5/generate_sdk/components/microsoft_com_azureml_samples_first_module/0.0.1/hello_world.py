# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

if __name__ == '__main__':
    print('Hello from AzureML!')
